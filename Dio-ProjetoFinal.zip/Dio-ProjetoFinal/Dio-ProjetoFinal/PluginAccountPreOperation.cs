﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;

namespace Dio_ProjetoFinal
{
    public class PluginAccountPreOperation : PluginImplementation
    {
        public override void ExecutePlugin(IServiceProvider serviceProvider)
        {

            if (Context.InputParameters.Contains("Target") && Context.InputParameters["Target"] is Entity)
            {
                Entity account = (Entity)Context.InputParameters["Target"];

                if (account.LogicalName == "account") 
                {
                    if (account.Attributes.Contains("telephone1")) 
                    {                      
                        var telefone = account["telephone1"].ToString();
                        					
                        string FetchContact = @"<?xml version='1.0'?>" +
                            "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>" +
                            "<entity name='contact'>" +
                            "<attribute name='fullname'/>" +
                            "<attribute name='telephone1'/>" +
                            "<attribute name='contactid'/>" +
                            "<order descending='false' attribute='fullname'/>" +
                            "<filter type='and'>" +
                            "<condition attribute='telephone1' value='" + telefone + "' operator='eq'/>" +
                            "</filter>" +
                        "</entity>" +
                        "</fetch>";

                        TracingService.Trace("FetchContact: " + FetchContact);
                        
                        var primarycontact = Service.RetrieveMultiple(new FetchExpression(FetchContact));

                        if (primarycontact.Entities.Count > 0)
                        {                            
                            foreach (var entityContact in primarycontact.Entities)
                            {
                                account["primarycontactid"] = new EntityReference("contact", entityContact.Id);
                            }
                        }
                    }
                }


            }
        }
    }
}
