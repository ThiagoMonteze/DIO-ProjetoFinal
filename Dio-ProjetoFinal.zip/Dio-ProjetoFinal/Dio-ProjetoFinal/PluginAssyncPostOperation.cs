﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;

namespace Dio_ProjetoFinal
{
    public class PluginAssyncPostOperation : PluginImplementation
    {
        public override void ExecutePlugin(IServiceProvider serviceProvider)
        {
            if (Context.InputParameters.Contains("Target") && Context.InputParameters["Target"] is Entity)
            {               
                Entity entidadeContexto = (Entity)Context.InputParameters["Target"];

                for (int i = 0; i < 10; i++)
                {                   
                    var Contact = new Entity("contact");                    
                    Contact.Attributes["firstname"] = "Contato Assinc vinculado a Conta";
                    Contact.Attributes["lastname"] = entidadeContexto["name"];
                    Contact.Attributes["parentcustomerid"] = new EntityReference("account", Context.PrimaryEntityId);
                    Contact.Attributes["ownerid"] = new EntityReference("systemuser", Context.UserId);

                    TracingService.Trace("firstname: " + Contact.Attributes["firstname"]);

                    Service.Create(Contact); 
                }
            }
        }
    }
}
