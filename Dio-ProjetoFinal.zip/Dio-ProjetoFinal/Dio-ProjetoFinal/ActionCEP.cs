﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;

namespace Dio_ProjetoFinal
{
    public class ActionCEP : PluginImplementation
    {
        public override void ExecutePlugin(IServiceProvider serviceProvider)
        {
            var cep = Context.InputParameters["CepInput"];
            TracingService.Trace("Cep informado: " + cep);

            var viaCEPUrl = $"https://viacep.com.br/ws/{cep}/json/";
            string result = string.Empty;
            using (WebClient client = new WebClient())
            {
                client.Headers[HttpRequestHeader.ContentType] = "application/json";
                client.Encoding = Encoding.UTF8;
                result = client.DownloadString(viaCEPUrl);
            }
            Context.OutputParameters["ResultadoCEP"] = result;

            TracingService.Trace("Resultado: " + result);
        }
    }
}
