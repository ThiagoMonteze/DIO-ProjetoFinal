﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;

namespace Dio_ProjetoFinal
{
    public class PluginAccountPostOperation : PluginImplementation
    {
        public override void ExecutePlugin(IServiceProvider serviceProvider)
        {
            if (Context.InputParameters.Contains("Target") && Context.InputParameters["Target"] is Entity)
            {                
                Entity entidadeContexto = (Entity)Context.InputParameters["Target"];

                if (!entidadeContexto.Contains("websiteurl")) 
                {
                    throw new InvalidPluginExecutionException("Campo websiteurl é obrigatório!");
                }
               
                var Task = new Entity("task");
              
                Task.Attributes["ownerid"] = new EntityReference("systemuser", Context.UserId);
                Task.Attributes["regardingobjectid"] = new EntityReference("account", Context.PrimaryEntityId);
                Task.Attributes["subject"] = "Visite nosso site: " + entidadeContexto["websiteurl"];
                Task.Attributes["description"] = "TASK criada via Plugin Post Operation";

                Service.Create(Task);
            }
        }
    }
}

