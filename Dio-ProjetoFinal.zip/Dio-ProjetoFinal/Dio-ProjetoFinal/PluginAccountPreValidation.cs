﻿using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Dio_ProjetoFinal
{
    public class PluginAccountPreValidation : PluginImplementation
    {
        public override void ExecutePlugin(IServiceProvider serviceProvider)
        {

            if (Context.InputParameters.Contains("Target") && Context.InputParameters["Target"] is Entity)
            {
                Entity account = null;

                account = (Entity)Context.InputParameters["Target"]; 

                TracingService.Trace("Entidade do Contexto: " + account.Attributes.Count); 

                if (account == null) 
                {
                    return; 
                }

                if (!account.Contains("telephone1")) 
                {
                    throw new InvalidPluginExecutionException("Campo Telefone principal é obrigatório!");
                }


            }
        }
    }
}
